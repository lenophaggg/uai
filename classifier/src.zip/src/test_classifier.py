import joblib
from pathlib import Path

BASE = Path(__file__).parent.parent.parent
MODEL_PATH = BASE / "classifier" / "models" / "router_clf.joblib"
clf = joblib.load(MODEL_PATH)

test_queries = [
    "кто ведет математику на фиит",
    "декан факультета фцпт",
    "преподаватель Иванов Иван Иванович",
    "электронная почта кафедры химии",
    "группа 8420",
    "контакты деканата",
    "когда будет собрание старост",
    "как найти расписание",
    "где находится общежитие",
    "что задали по информатике",
    "где взять справку",
    "кто преподает информатику в группе 8310",
    "какой график работы библиотеки"
]

for query in test_queries:
    label = clf.predict([query])[0]
    print(f"{query!r:50s}  =>  {label}")
